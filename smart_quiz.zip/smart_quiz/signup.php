<!DOCTYPE html>
<html lang="en">
<head>
<title>E-LITERATURE</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="index.php." class="w3-bar-item w3-button w3-padding-large">BACK</a>
   
    <div class="w3-dropdown-hover w3-hide-small">
        
      </div>
    </div>
    <a href="adminlogin.html" class="w3-padding-large w3-hover-grey w3-hide-small w3-right"><i class="glyphicon glyphicon-user"></i></a>
  </div>
</div>



<!-- Main content: shift it to the right by 250 pixels when the sidebar is visible -->
<<div class="w3-main" style="margin-left:250px">
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:700px">
    <h5 class= "w3-padding-64"><span class="w3-tag w3-wide">Little Red Riding Hood</span></h5>
    <div  class="w3-serif">
      <p>The story revolves around a girl called Little Red Riding Hood, after the red hooded cape that she wears. The girl walks through the woods to deliver food to her sickly grandmother (wine and cake depending on the translation). In the Grimms' version, her mother had ordered her to stay strictly on the path.

A stalking wolf wants to eat the girl and the food in the basket. He asks her where she is going. She tells him. He suggests that she pick some flowers as a present for her grandmother, which she does. In the meantime, he goes to the grandmother's house and gains entry by pretending to be Riding Hood. He swallows the grandmother whole (in some stories, he locks her in the closet) and waits for the girl, disguised as the grandmother.


Gustave Doré's engraving of the scene: "She was astonished to see how her grandmother looked."
When the girl arrives, she notices that her grandmother looks very strange. She says, "What a deep voice you have!" ("The better to greet you with", responds the wolf), "Goodness, what big eyes you have!" ("The better to see you with", responds the wolf), "And what big hands you have!" ("The better to embrace you with", responds the wolf), and lastly, "What a big mouth you have" ("The better to eat you with!", responds the wolf), at which point the wolf jumps out of the bed and eats her, too. Then he falls asleep. In Charles Perrault's version of the story (the first version to be published), the tale ends here.

In later and better-known versions, the story continues. A woodcutter in the French version, or a hunter in the Brothers Grimm and traditional German versions, comes to the rescue with an axe, and cuts open the sleeping wolf. Little Red Riding Hood and her grandmother emerge shaken, but unharmed. Then they fill the wolf's body with heavy stones. The wolf awakens and attempts to flee, but the stones cause him to collapse and die. In the Grimms' version, the wolf leaves the house and tries to drink out of a well, but the stones in his stomach cause him to fall in and drown (similarly to the story of "The Wolf and the Seven Little Kids").

Sanitized versions of the story have the grandmother locked in the closet instead of being eaten and some have Little Red Riding Hood saved by the lumberjack as the wolf advances on her rather than after she is eaten, where the woodcutter kills or simply chases away the wolf with his axe.</p>
    </div>
   
  
  <!-- Pagination -->
  <div class="w3-center w3-padding-32">
    <div class="w3-bar">
      <a class="w3-button w3-hover-black" href="signup.php">1</a>
      <a class="w3-button w3-hover-black" href="page2.php">2</a>
      <a class="w3-button w3-hover-black" href="page3.php">3</a>
      <a class="w3-button w3-hover-black" href="page4.php">4</a>
      <a class="w3-button w3-hover-black" href="page5.php">5</a>
    </div>
  <!-- Footer -->
<div class='w3-container w3-white'>
    <!-- Gunakan ayat yang lebih sesuai pada bahagian ini -->
    <p> Copyright © 2020-2024 : E-literature</p>
    <p>The aim of education is the knowledge, not of facts, but of values.</p>
</div>

<!-- END MAIN -->
</div>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}
</script>

</body>
</html>