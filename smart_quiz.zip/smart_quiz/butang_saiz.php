<br>
<!-- fungsi mengubah saiz tulisan bagi kepelbagaian pengguna-->
<script>
function resizeText(multiplier) {
    var elem = document.getElementById("besar");
    var currentSize = elem.style.fontSize || 1;
    if(multiplier==2)
    {
        elem.style.fontSize = "1em";
    }
    else
    {
        elem.style.fontSize = ( parseFloat(currentSize)+(multiplier * 0.2)) + "em";
    }
}        <button class="w3-button w3-hover-black">CHANGE TEXT SIZE</button>
</script>
<!-- Kod untuk butang mengubah saiz tulisan -->
<button class="w3-button w3-black w3-hover-dark-grey">CHANGE TEXT SIZE</button>
<input class="w3-btn w3-round-xlarge w3-grey"  name='reSize1' type='button' value='reset' onclick="resizeText(2)"/>
<input class="w3-btn w3-round-xlarge w3-grey"  name='reSize' type='button' value='&nbsp;+&nbsp;' onclick="resizeText(1)"/>
<input class="w3-btn w3-round-xlarge w3-grey"  name='reSize2' type='button' value='&nbsp;-&nbsp;' onclick="resizeText(-1)"/>