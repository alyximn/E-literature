
</div>
<!-- footer -->
<div class="w3-container w3-black">
<p> Copyright © 2020-2024 : E-literature </p>
<p>The aim of education is the knowledge, not of facts, but of values.</p>
</div>

</body>
</html>