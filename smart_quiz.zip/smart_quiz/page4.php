<!DOCTYPE html>
<html lang="en">
<head>
<title>Thoughtsbox.com</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="index.php" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    
    <div class="w3-dropdown-hover w3-hide-small">
      </div>
    </div>
    <a href="adminlogin.html" class="w3-padding-large w3-hover-grey w3-hide-small w3-right"><i class="glyphicon glyphicon-user"></i></a>
  </div>
</div>


<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->
<div id="navDemo" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:46px">
  <a href="poem.html" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">POEMS</a>
  <a href="shortstory.html" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">SHORT STORIES</a>
  <a href="#contact" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">CONTACT</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">MERCH</a>
</div>
<!-- Main content: shift it to the right by 250 pixels when the sidebar is visible -->
<div class="w3-main" style="margin-left:250px">
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:700px">
    <h5 class= "w3-padding-64"><span class="w3-tag w3-wide">A Blind Man With An Elephant</span></h5>
    <div  class="w3-serif">
      <p>A group of blind men heard that a strange animal, called an elephant, had been brought to the town, but none of them were aware of its shape and form. Out of curiosity, they said: "We must inspect and know it by touch, of which we are capable". So, they sought it out, and when they found it they groped about it. The first person, whose hand landed on the trunk, said, "This being is like a thick snake". For another one whose hand reached its ear, it seemed like a kind of fan. As for another person, whose hand was upon its leg, said, the elephant is a pillar like a tree-trunk. The blind man who placed his hand upon its side said the elephant, "is a wall". Another who felt its tail, described it as a rope. The last felt its tusk, stating the elephant is that which is hard, smooth and like a spear.<p/>

<p>In some versions, the blind men then discover their disagreements, suspect the others to be not telling the truth and come to blows. The stories also differ primarily in how the elephant's body parts are described, how violent the conflict becomes and how (or if) the conflict among the men and their perspectives is resolved. In some versions, they stop talking, start listening and collaborate to "see" the full elephant. In another, a sighted man enters the parable and describes the entire elephant from various perspectives, the blind men then learn that they were all partially correct and partially wrong. While one's subjective experience is true, it may not be the totality of truth.</p>


<p>The parable has been used to illustrate a range of truths and fallacies; broadly, the parable implies that one's subjective experience can be true, but that such experience is inherently limited by its failure to account for other truths or a totality of truth. At various times the parable has provided insight into the relativism, opaqueness or inexpressible nature of truth, the behavior of experts in fields of contradicting theories, the need for deeper understanding, and respect for different perspectives on the same object of observation. In this respect, it provides an easily understood and practical example that illustrates ontologic reasoning. That is, simply put, what things exist, what is their true nature, and how can their relations to each other be accurately categorized? For example, is the elephant's trunk a snake, or its legs trees, just because they share some similarities with those? Or is that just a misapprehension that differs from an underlying reality? And how should human beings treat each other as they strive to understand better (anger, respect, tolerance or intolerance)?</p>
    </div>
   
  
 <!-- Pagination -->
  <div class="w3-center w3-padding-32">
    <div class="w3-bar">
      <a class="w3-button w3-hover-black" href="signup.php">1</a>
      <a class="w3-button w3-hover-black" href="page2.php">2</a>
      <a class="w3-button w3-hover-black" href="page3.php">3</a>
      <a class="w3-button w3-hover-black" href="page4.php">4</a>
      <a class="w3-button w3-hover-black" href="page5.php">5</a>
    </div>
  <!-- Footer -->
<div class='w3-container w3-white'>
    <!-- Gunakan ayat yang lebih sesuai pada bahagian ini -->
    <p> Copyright © 2020-2024 : E-literature </p>
    <p>The aim of education is the knowledge, not of facts, but of values.</p>
</div>

<!-- END MAIN -->
</div>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}
</script>

</body>
</html>