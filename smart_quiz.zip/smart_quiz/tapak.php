class='w3-btn w3-round-xlarge w3-grey w3-card '
<div class='w3-responsive'>
<table border='1' id='besar' class='w3-table-all w3-hoverable w3-margin-top'>


<div style='border:16px solid black' class='w3-panel w3-hover-border-dark-grey' >

<div class="w3-round w3-white w3-large">TEACHERS LIST</div>
</tr>
</div>

<?PHP include ('../butang_saiz.php'); ?>
<div class='w3-responsive'>
<table border='1' id='besar' class='w3-table-all w3-hoverable w3-margin-top w3-margin-bottom'> 

