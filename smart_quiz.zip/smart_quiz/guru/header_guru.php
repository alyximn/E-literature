<?PHP 
# Memulakan fungsi session
session_start();

# Memanggil fail guard_guru.php
include ('guard_guru.php');

# Memanggil fail connection dari folder utama
include ('../connection.php');

# Menguji pembolehubah session tahap mempunyai nilai atau tidak
if(empty($_SESSION['tahap']))
{
    # proses untuk mendapatkan tahap pengguna yang sedang login samada admin atau guru
    $arahan_semak_tahap="select* from guru where
    nokp_guru   =   '".$_SESSION['nokp_guru']."'
    limit 1";
    $laksana_semak_tahap=mysqli_query($condb,$arahan_semak_tahap);
    $data=mysqli_fetch_array($laksana_semak_tahap);
    $_SESSION['tahap']=$data['tahap'];
}
?>

<!doctype HTML>
<html>
    <head>
    <title>E-LITERATURE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
}
</style>
</head>
<body background='../images/sma.jpg'>

<!-- header -->
<div class="w3-container w3-black w3-margin-bottom">
<p style="font-size:30px">TEACHER'S SECTION/ADMINISTRATOR</p>
</div>

<!-- menu -->

<div class="w3-bar w3-black">
  <a  href='index.php' class="w3-bar-item w3-button">HOME PAGE</a>
  <a  href='../logout.php' class="w3-bar-item w3-button w3-right w3-red ">LOGOUT NOW</a>


  <?PHP if($_SESSION['tahap']=='ADMIN'){ ?>
  <div class="w3-dropdown-hover">
    <button class="w3-button">ADMINISTRATOR</button>
    <div class="w3-dropdown-content w3-bar-block w3-card-4">
      <a href='guru_senarai.php'class="w3-bar-item w3-button">TEACHERS DATA</a>
      <a href='murid_senarai.php' class="w3-bar-item w3-button">STUDENT MANAGEMENT</a>
      <a  href='senarai_kelas.php' class="w3-bar-item w3-button">CLASS MANAGEMENT</a>
    </div>
  </div>
  <?PHP } ?>


  <div class="w3-dropdown-hover">
    <button class="w3-button">TEACHER</button>
    <div class="w3-dropdown-content w3-bar-block w3-card-4">
      <a href='soalan_daftar.php' class="w3-bar-item w3-button">QUESTION MANAGEMENT</a>
      <a href='analisis.php' class="w3-bar-item w3-button">PERFORMANCE ANALYSIS</a>
      <a href='../logout.php' class="w3-bar-item w3-button">LOG OUT NOW</a>
      </div>
  </div>



</div>



<!-- isi kandungan -->
<div class="w3-container">