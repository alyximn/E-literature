<?php
include('header_guru.php');

if(!empty($_POST)) {
    $soalan = mysqli_real_escape_string($condb, $_POST['soalan']);
    $jawapan_a = mysqli_real_escape_string($condb, $_POST['jawapan_a']);
    $jawapan_b = mysqli_real_escape_string($condb, $_POST['jawapan_b']);
    $jawapan_c = mysqli_real_escape_string($condb, $_POST['jawapan_c']);
    $jawapan_d = mysqli_real_escape_string($condb, $_POST['jawapan_d']);
 
    // Check if a file was uploaded
    if($_FILES['gambar']['size'] != 0) {
        // Handle file upload here
        // You need to implement the file upload logic
        // Example: move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file);
    }
    
    // Prepare insertion query
    $arahan_simpan = "INSERT INTO soalan (no_set, soalan, gambar, jawapan_a, jawapan_b, jawapan_c, jawapan_d)
                      VALUES ('".$_GET['no_set']."', '$soalan', '', '$jawapan_a', '$jawapan_b', '$jawapan_c', '$jawapan_d')";

    // Check if all required fields are filled
    if(empty($soalan) || empty($jawapan_a) || empty($jawapan_b) || empty($jawapan_c) || empty($jawapan_d)) {
        die("<script>alert('Sila lengkapkan maklumat'); window.history.back();</script>");
    }

    // Execute insertion query
    if(mysqli_query($condb, $arahan_simpan)) {
        echo "<script>alert('Pendaftaran BERJAYA.'); window.location.href='soalan_daftar.php?no_set=".$_GET['no_set']."&topik=".$_GET['topik']."';</script>";
    }
    else {
        echo "<script>alert('Pendaftaran GAGAL.'); window.location.href='soalan_daftar.php?no_set=".$_GET['no_set']."&topik=".$_GET['topik']."';</script>";
    }
}
?>
