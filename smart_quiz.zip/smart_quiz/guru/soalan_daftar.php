<?php
include('header_guru.php');

if(!empty($_POST)) {
    $soalan = mysqli_real_escape_string($condb,$_POST['soalan']);
    $jawapan_a = mysqli_real_escape_string($condb,$_POST['jawapan_a']);
    $jawapan_b = mysqli_real_escape_string($condb,$_POST['jawapan_b']);
    $jawapan_c = mysqli_real_escape_string($condb,$_POST['jawapan_c']);
    $jawapan_d = mysqli_real_escape_string($condb,$_POST['jawapan_d']);
 
    if($_FILES['gambar']['size'] != 0) {
        // Uploading image code
    }
    else {
        $arahan_simpan="insert into soalan
        (no_set,soalan,gambar,jawapan_a,jawapan_b,jawapan_c,jawapan_d)
        values ('".$_GET['no_set']."','$soalan','','$jawapan_a','$jawapan_b','$jawapan_c','$jawapan_d')";
    }

    if(empty($soalan) or empty($jawapan_a) or empty($jawapan_b) or empty($jawapan_c) or empty($jawapan_d)) {
        die("<script>alert('Sila lengkapkan maklumat'); window.history.back();</script>");
    }

    if(mysqli_query($condb,$arahan_simpan)) {
        echo "<script>alert('Pendaftaran BERJAYA.'); window.location.href='soalan_daftar.php?no_set=".$_GET['no_set']."&topik=".$_GET['topik']."';</script>";
    }
    else {
        echo "<script>alert('Pendaftaran GAGAL.'); window.location.href='soalan_daftar.php?no_set=".$_GET['no_set']."&topik=".$_GET['topik']."';</script>";
    }
}
?>

<!-- Corrected HTML structure -->
<div style='border:16px solid black' class='w3-panel w3-hover-border-dark-grey'>
    <div class="w3-round w3-white w3-large">QUESTION LIST</div>
</div>

<?php include ('../butang_saiz.php'); ?>
<div class='w3-responsive'>
    <table border='1' id='besar' class='w3-table-all w3-hoverable w3-margin-top w3-margin-bottom'> 
        <tr class='w3-black'>
            <td>QUESTION</td>
            <td bgcolor='black'>Answer A (Betul)</td>
            <td bgcolor='black'>Answer B</td>
            <td bgcolor='black'>Answer C</td>
            <td bgcolor='black'>Answer D</td>
            <td></td>
        </tr>
        <tr>
            <form action='' method='POST' enctype='multipart/form-data'>
                <td><textarea name='soalan' rows="4" cols="25"></textarea></td>
                <td bgcolor='grey'><textarea name='jawapan_a' rows="4" cols="25"></textarea></td>
                <td bgcolor='grey'><textarea name='jawapan_b' rows="4" cols="25"></textarea></td>
                <td bgcolor='grey'><textarea name='jawapan_c' rows="4" cols="25"></textarea></td>
                <td bgcolor='grey'><textarea name='jawapan_d' rows="4" cols="25"></textarea></td>
                <td><input class="w3-button  w3-black w3-hover-dark-grey" type='submit' value='simpan'></td>
            </form>
        </tr>

        <?php
        $arahan_soalan="select* from soalan where no_set='".$_GET['no_set']."' order by no_soalan DESC";
        $laksana_soalan=mysqli_query($condb,$arahan_soalan);

        while ($data=mysqli_fetch_array($laksana_soalan)) {
            $data_get=array(
                'no_set'    =>  $data['no_set'],
                'no_soalan' =>  $data['no_soalan'],
                'soalan'    =>  $data['soalan'],
                'jawapan_a' =>  $data['jawapan_a'],
                'jawapan_b' =>  $data['jawapan_b'],
                'jawapan_c' =>  $data['jawapan_c'],
                'jawapan_d' =>  $data['jawapan_d']
            );
            echo "<tr>
                <td>".$data['soalan']."</td>
                <td>".$data['jawapan_a']."</td>
                <td>".$data['jawapan_b']."</td>
                <td>".$data['jawapan_c']."</td>
                <td>".$data['jawapan_d']."</td>
                <td class='w3-center'>
                    <a class='w3-btn w3-round-xlarge w3-grey w3-card w3-margin-top w3-margin-bottom' href='soalan_kemaskini.php?".http_build_query($data_get)."'> Update </a>
                    <a class='w3-btn w3-round-xlarge w3-grey w3-card' href='padam.php?jadual=soalan&medan=no_soalan&kp=".$data['no_soalan']."' onClick=\"return confirm('Are you sure you want to delete this?')\" > Delete </a>
                </td>
            </tr>";
        }
        ?>
    </table>
</div>

<?php include('footer_guru.php'); ?>
