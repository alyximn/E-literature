<?PHP
# memulakan fungsi session_start bagi membolehkan pembolehubah super global
session_start(); ?>

<!doctype HTML>
<html>
    <head>
    <title>FLAUNER.COM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
}
</style>
</head>
<body background='images/gambar.1.jpg'>

<!-- header -->
<div class="w3-container w3-white">
<p style="font-size:30px">FLANEUR.COM</p>

<!-- menu -->
<div class="w3-bar w3-black">


 <!-- Menu bahagian Murid -->
<?PHP if(!empty ($_SESSION) and basename($_SERVER['PHP_SELF']) != 'index.php')
{ ?>

<?PHP echo"<span class='w3-bar-item'>WELCOME.PLEASE LOG IN</span> "; 

?>
</div>
<!-- isi kandungan -->

<div class='w3-container'>
TABLE OF CONTENT

</div>

<!-- footer -->
<div class='w3-container w3-white'>
    <!-- Gunakan ayat yang lebih sesuai pada bahagian ini -->
    <p> Copyright © 2020-2022 : Flaneur.com </p>
    <p>The aim of education is the knowledge, not of facts, but of values.</p>
</div>

</body>
</html>
