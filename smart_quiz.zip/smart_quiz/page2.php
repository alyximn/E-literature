<!DOCTYPE html>
<html lang="en">
<head>
<title>Thoughtsbox.com</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="index.php" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    
    <div class="w3-dropdown-hover w3-hide-small">
      </div>
    </div>
    <a href="adminlogin.html" class="w3-padding-large w3-hover-grey w3-hide-small w3-right"><i class="glyphicon glyphicon-user"></i></a>
  </div>
</div>

  <<div class="w3-main" style="margin-left:250px">
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:700px">
    <h5 class= "w3-padding-64"><span class="w3-tag w3-wide">Rapunzel</span></h5>
    <div  class="w3-serif">
      <p>A lonely couple, who long for a child, live next to a large, extensive, high-walled subsistence garden, belonging to a sorceress.[a] The wife, experiencing pregnancy cravings, longs for the rapunzel that she sees growing in the garden (rapunzel is either the root vegetable Campanula rapunculus, or the salad green Valerianella locusta).[5] She refuses to eat anything else and begins to waste away. Her husband fears for her life and one night he breaks into the garden to get some for her. When he returns, she makes a salad out of it and eats it, but she longs for more so her husband returns to the garden to retrieve some more. As he scales the wall to return home, the sorceress catches him and accuses him of theft. He begs for mercy and she agrees to be lenient, allowing him to take all the rapunzel he wants on condition that the baby be given to her when it's born.[b] Desperate, he agrees.</p>

<p>When the wife has a baby girl, the sorceress takes her to raise as her own and names her "Rapunzel" after the plant her mother craved (in one version, her parents move away before she's born in an attempt to avoid surrendering her, only for the sorceress to turn up at their door upon her birth, unhampered by their attempt at relocation). She grows up to be a beautiful child with long golden hair.[c] When she turns twelve, the sorceress locks her up in a tower in the middle of the woods, with neither stairs nor a door, and only one room and one window.[d] In order to visit her, the sorceress stands at the bottom of the tower and calls out:

Rapunzel!
Rapunzel!
Let down your hair
That I may climb thy golden stair![e]
Jacob Grimm ostensibly believed that the strong alliteration of the rhyme indicated that it was a survival of the ancient form of Germanic poetry known as Stabreim, but in actuality, it was his liberal adaption of Schulz's direct German translation of Charlotte-Rose de Caumont de La Force's older French version Persinette, Persinette, descendez vos cheveux que je monte. </p>

<p>One day, a prince rides through the forest and hears Rapunzel singing from the tower. Entranced by her ethereal voice, he searches for her and discovers the tower, but is unable to enter it. He returns often, listening to her beautiful singing, and one day sees the sorceress visit her as usual and learns how to gain access. When the sorceress leaves, he bids Rapunzel to let her hair down. When she does so, he climbs up and they fall in love. He eventually asks her to marry him, and she agrees.</p>

<p>Together they plan a means of escape, wherein he will come each night (thus avoiding the sorceress who visits her by day) and bring Rapunzel a piece of silk that she will gradually weave into a ladder. Before the plan can come to fruition, however, she has sexual intercourse with him. In the first edition (1812) of Kinder- und Hausmärchen (Children's and Household Tales, most commonly known in English as Grimms' Fairy Tales), she innocently says that her dress is growing tight around her waist, hinting at pregnancy.[12] In later editions, she asks "Dame Gothel",[f] in a moment of forgetfulness, why it is easier for her to draw up the prince than her.[14] In anger, the sorceress cuts off her hair and casts her out into the wilderness to fend for herself.</p>

<p>When the prince calls that night, the sorceress lets the severed hair down to haul him up. To his horror, he finds himself meeting her instead of Rapunzel, who is nowhere to be found. After she tells him in a rage that he will never see Rapunzel again, he leaps or falls from the tower and lands in a thorn bush. Although it breaks his fall and saves his life, it scratches his eyes and blinds him.</p>

<p> For years, he wanders through the wastelands of the country and eventually comes to the wilderness, where Rapunzel now lives with the twins whom she has given birth to, a boy and girl. One day, as she sings, he hears her voice again, and they are reunited. When they fall into each other's arms, her tears fall into his eyes and immediately restore his sight. He leads her and their twins to his kingdom where they live happily ever after.[g]

Another version of the story ends with the revelation that the sorceress had untied Rapunzel's hair after the prince leapt from the tower, and it slipped from her hands and landed far below, leaving her trapped in the tower.[16]</p>
    </div>
   
  
 <!-- Pagination -->
  <div class="w3-center w3-padding-32">
    <div class="w3-bar">
     <a class="w3-button w3-hover-black" href="signup.php">1</a>
      <a class="w3-button w3-hover-black" href="page2.php">2</a>
      <a class="w3-button w3-hover-black" href="page3.php">3</a>
      <a class="w3-button w3-hover-black" href="page4.php">4</a>
      <a class="w3-button w3-hover-black" href="page5.php">5</a>
    </div>
  <!-- Footer -->
<div class='w3-container w3-white'>
    <!-- Gunakan ayat yang lebih sesuai pada bahagian ini -->
    <p> Copyright © 2020-2022 : E-literature </p>
    <p>The aim of education is the knowledge, not of facts, but of values.</p>
</div>

<!-- END MAIN -->
</div>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}
</script>

</body>
</html>