<!DOCTYPE html>
<html lang="en">
<head>
<title>E-LITERATURE</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>
<


<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey">

<!-- w3-content defines a container for fixed size centered content, 
and is wrapped around the whole page content, except for the footer in this example -->
<div class="w3-content" style="max-width:1400px">

<!-- Header -->
<header class="w3-container w3-left-align w3-padding-32"> 
  <h1><b>USER MANUAL</b></h1>
</header>

<!-- Grid -->
<div class="w3-row">

<!-- Blog entries -->
<div class="w3-col l8 s12">
  <!-- Blog entry -->
  <div class="w3-card-4 w3-margin w3-white">
    <img src="step1.jpeg"  style="width:100%">
    <div class="w3-container">
      <h3><b>LOG IN</b></h3>
      <h5>Please insert your log in data <span class="w3-opacity"></span></h5>
    </div>
  </div>
  <hr>

  <!-- Blog entry -->
  <div class="w3-card-4 w3-margin w3-white">
  <img src="step2.jpeg"  style="width:100%">
    <div class="w3-container">
      <h3><b>DATA MANAGEMENT</b></h3>
      <h5>This page where you can analyze student's data ,teacher's data<span class="w3-opacity"></span></h5>
    </div>

    <div class="w3-center" class="w3-serif" class="w3-container">
      
      <div class="w3-row" >
        <div class="w3-right" class="w3-col m8 s12">
          
        </div>
        <div class="w3-col m4 w3-hide-small">
          
        </div>
      </div>
    </div>
  </div>

  <!-- Blog entry -->
  <div class="w3-card-4 w3-margin w3-white">
  <img src="step3.jpeg"  style="width:100%">
    <div class="w3-container">
      <h3><b>QUESTION MANAGEMENT</b></h3>
      
    </div>

    <div class="w3-center" class="w3-serif" class="w3-container">
        <h5>You can analyze student's performance and organize questions here <span class="w3-opacity"></span></h5>
      <div class="w3-row ">
        <div class="w3-right" class="w3-col m8 s12 w3-left-allign">
          <a href="index.php"class="w3-button w3-padding-large w3-white w3-border"><b>GO BACK »</b></button></a>
        </div>
        <div class="w3-col m4 w3-hide-small">
          
        </div>
      </div>
    </div>
  </div>

    
    </div>
  </div>
  
<!-- END Introduction Menu -->
</div>

<!-- END GRID -->
</div><br>

<!-- END w3-content -->
</div>



</body>
</html>
