<?php
# Start session
session_start();

# Check for the existence of nokp, katalaluan, and jenis data.
if(empty($_POST['nokp']) || empty($_POST['katalaluan']) || empty($_POST['jenis'])) {
    # Stop the program if the above data does not exist
    echo "<script>alert('Sila masukkan nokp dan katalaluan.'); window.location.href='index.php';</script>";
    exit; // Added exit to stop execution after redirect
}

# Set variables if the user type is murid
if($_POST['jenis'] == 'murid') {
    $table = "murid";
    $field1 = "nokp_murid";
    $field2 = "katalaluan_murid";
    $field3 = "nama_murid";
    $location = "murid/pilih_latihan.php";
}
# Set variables if the user type is guru
else if($_POST['jenis'] == 'guru') {
    $table = "guru";
    $field1 = "nokp_guru";
    $field2 = "katalaluan_guru";
    $field3 = "nama_guru";
    $location = "guru/index.php";
}
else {
    # Handle invalid user type
    echo "<script>alert('Jenis pengguna tidak sah.'); window.location.href='index.php';</script>";
    exit; // Added exit to stop execution after redirect
}

# Include the connection.php file
include('connection.php');

# Sanitize and retrieve POST data
$nokp = mysqli_real_escape_string($condb, $_POST['nokp']);
$katalaluan = mysqli_real_escape_string($condb, $_POST['katalaluan']);

# SQL query to compare data
$sql = "SELECT * FROM $table WHERE $field1 = '$nokp' AND $field2 = '$katalaluan' LIMIT 1";

# Execute the login query
$result = mysqli_query($condb, $sql);

# If one matching record is found
if(mysqli_num_rows($result) == 1) {
    # Login successful, set session variable values
    $data = mysqli_fetch_array($result);
    $_SESSION[$field3] = $data[$field3];
    $_SESSION[$field1] = $data[$field1];
    echo "<script>window.location.href='$location';</script>";
}
else {
    # Login failed
    echo "<script>alert('Login Gagal'); window.history.back();</script>";
}

# Close the connection between the system and the database
mysqli_close($condb);
?>
