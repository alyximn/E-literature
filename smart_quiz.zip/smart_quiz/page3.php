<!DOCTYPE html>
<html lang="en">
<head>
<title>Thoughtsbox.com</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="index.php" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    
    <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button" title="More"><i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="#" class="w3-bar-item w3-button"></a>
        <a href="#contact" class="w3-bar-item w3-button"></a>
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>

<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->
<div id="navDemo" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:46px">
  <a href="poem.html" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">POEMS</a>
  <a href="shortstory.html" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">SHORT STORIES</a>
  <a href="#contact" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">CONTACT</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">MERCH</a>
</div>
<!-- Main content: shift it to the right by 250 pixels when the sidebar is visible -->
<div class="w3-main" style="margin-left:250px">
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:700px">
    <h5 class= "w3-padding-64"><span class="w3-tag w3-wide">Snow White</span></h5>
    <div  class="w3-serif">
      <p>Snow White grows into an absolutely lovely, fair and beautiful young maiden. Meanwhile, the queen, who believes she got rid of Snow White a decade earlier, asks her mirror once again: "Mirror mirror on the wall, who now is the fairest one of all?" The mirror tells her that not only is Snow White still the fairest in the land, but she is also currently hiding with the dwarfs.[1] The queen is furious and decides to kill the girl herself. First, she appears at the dwarfs' cottage, disguised as an old peddler, and offers Snow White a colourful, silky laced bodices as a present. The queen laces her up so tightly that Snow White faints; the dwarfs return just in time to revive Snow White by loosening the laces. Next, the queen dresses up as a comb seller and convinces Snow White to take a beautiful comb as a present; she strokes Snow White's hair with the poisoned comb. The girl is overcome by the poison from the comb, but is again revived by the dwarfs when they remove the comb from her hair. Finally, the queen disguises herself as a farmer's wife and offers Snow White a poisoned apple. Snow White is hesitant to accept it, so the queen cuts the apple in half, eating the white (harmless) half and giving the red poisoned half to Snow White; the girl eagerly takes a bite and then falls into a coma, causing the Queen to think she has finally triumphed. This time, the dwarfs are unable to revive Snow White, and, assuming that the queen has finally killed her, they place her in a glass casket as a funeral for her.</p>

<p>The next day, a prince stumbles upon a seemingly dead Snow White lying in her glass coffin during a hunting trip. After hearing her story from the Seven Dwarfs, the prince is allowed to take Snow White to her proper resting place back at her father's castle. All of a sudden, while Snow White is being transported, one of the prince's servants trips and loses his balance. This dislodges the piece of the poisoned apple from Snow White's throat, magically reviving her.[6] The Prince is overjoyed with this miracle, and he declares his love for the now alive and well Snow White, who, surprised to meet him face to face, humbly accepts his marriage proposal. The prince invites everyone in the land to their wedding, except for Snow White's stepmother.</p>

<p>The queen, believing herself finally to be rid of Snow White, asks again her magic mirror who is the fairest in the land. The mirror says that there is a bride of a prince, who is yet fairer than she. The queen decides to visit the wedding and investigate. Once she arrives, the Queen becomes frozen with rage and fear when she finds out that the prince's bride is her stepdaughter, Snow White herself. The furious Queen tries to sow chaos and attempts to kill her again, but the prince recognizes her as a threat to Snow White when he learns the truth from his bride. As punishment for the attempted murder of Snow White, the prince orders the Queen to wear a pair of red-hot iron slippers and to dance in them until she drops dead. With the evil Queen finally defeated and dead, Snow White's wedding to the prince peacefully continues.</p>
    </div>
   
  
  <!-- Pagination -->
  <div class="w3-center w3-padding-32">
    <div class="w3-bar">
      <a class="w3-button w3-hover-black" href="signup.php">1</a>
      <a class="w3-button w3-hover-black" href="page2.php">2</a>
      <a class="w3-button w3-hover-black" href="page3.php">3</a>
      <a class="w3-button w3-hover-black" href="page4.php">4</a>
      <a class="w3-button w3-hover-black" href="page5.php">5</a>
  </div>

  <!-- Footer -->
<div class='w3-container w3-white'>
    <!-- Gunakan ayat yang lebih sesuai pada bahagian ini -->
    <p> Copyright © 2020-2024 : E-literature </p>
    <p>The aim of education is the knowledge, not of facts, but of values.</p>
</div>

<!-- END MAIN -->
</div>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}
</script>

</body>
</html>