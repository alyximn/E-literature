<!DOCTYPE html>
<html lang="en">
<head>
<title>E-LITERATURE</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>
<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href=".html" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="poem.html" class="w3-bar-item w3-button w3-padding-large w3-hide-small">POEMS</a>
    <a href="shortstory.html" class="w3-bar-item w3-button w3-padding-large w3-hide-small">SHORT STORIES</a>
    <a href="blogging.html" class="w3-bar-item w3-button w3-padding-large w3-hide-small">BLOG</a>
        
      </div>
    </div>
    <a href="adminlogin.html" class="w3-padding-large w3-hover-grey w3-hide-small w3-right"><i class="glyphicon glyphicon-user"></i></a>
  </div>
</div>


<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->
<div id="navDemo" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:46px">
  <a href="poem.html" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">POEMS</a>
  <a href="shortstory.html" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">SHORT STORIES</a>
  <a href="#contact" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">CONTACT</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">MERCH</a>
</div>

<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey">

<!-- w3-content defines a container for fixed size centered content, 
and is wrapped around the whole page content, except for the footer in this example -->
<div class="w3-content" style="max-width:1400px">

<!-- Header -->
<header class="w3-container w3-center w3-padding-32"> 
  <h1><b>READINGS</b></h1>
  <p>Word by word of word by Heart</p>
</header>

<!-- Grid -->
<div class="w3-row">

<!-- Blog entries -->
<div class="w3-col l8 s12">
  <!-- Blog entry -->
  <div class="w3-card-4 w3-margin w3-white">
    <img src="flower.jpg"  style="width:100%">
    <div class="w3-container">
      <h3><b>FEELINGS</b></h3>
      <h5>A phrase i dicipher, <span class="w3-opacity">August 8, 2023</span></h5>
    </div>

    <div class="w3-center" class="w3-serif" class="w3-container">
      <p>Have you ever lay down and wonder how our body develop feelings?like the feelings within our chest how sometimes it could be uneasy a lil bit of a burn and heavy.Electrified sensation quivers around of attentiveness was it really from the heart that pumps blood? </p>
      <div class="w3-row">
        <div class="w3-right" class="w3-col m8 s12">
          <a href="comment.html"class="w3-button w3-padding-large w3-white w3-border"><b>comment »</b></button></a>
        </div>
      </div>
    </div>
  </div>
  <hr>

  <!-- Blog entry -->
  <div class="w3-card-4 w3-margin w3-white">
  <img src="flower.jpg"  style="width:100%">
    <div class="w3-container">
      <h3><b>VISUALIZED VIEW</b></h3>
      <h5>A pov i wish <span class="w3-opacity">July 16, 2023</span></h5>
    </div>

    <div class="w3-center" class="w3-serif" class="w3-container">
      <p>I want you to look at me
in the way a book you're interested to read
even though unsealed curiosity boils,attentiveness gaze,heart fulfilled to know more about me</p>
      <div class="w3-row" >
        <div class="w3-right" class="w3-col m8 s12">
          <a href="comment.html"class="w3-button w3-padding-large w3-white w3-border"><b>comment »</b></button></a>
        </div>
        <div class="w3-col m4 w3-hide-small">
          
        </div>
      </div>
    </div>
  </div>

  <!-- Blog entry -->
  <div class="w3-card-4 w3-margin w3-white">
  <img src="flower.jpg"  style="width:100%">
    <div class="w3-container">
      <h3><b>CURIOUSITY</b></h3>
      <h5>i wonder <span class="w3-opacity">July 16, 2023</span></h5>
    </div>

    <div class="w3-center" class="w3-serif" class="w3-container">
      <p>i don't know if i like you 
well at first i did as much as i tried to deny that it would be a false statement because as soon as a glance fall down to you a slight gasped pinched my feelings.</p>
      <div class="w3-row ">
        <div class="w3-right" class="w3-col m8 s12 w3-left-allign">
          <a href="comment.html"class="w3-button w3-padding-large w3-white w3-border"><b>comment »</b></button></a>
        </div>
        <div class="w3-col m4 w3-hide-small">
          
        </div>
      </div>
    </div>
  </div>
<!-- END BLOG ENTRIES -->
</div>

<!-- Introduction menu -->
<div class="w3-col l4">
  <!-- About Card -->
  <div class="w3-card w3-margin w3-margin-top">
  <img src="shelf.jpg" style="width:100%">
    <div class="w3-container w3-white">
      <h4><b>Alya iman by name </b></h4>
      <p>A page where all thoughts could be recognize.</p>
    </div>
  </div><hr>
  
  <!-- Posts -->
  <div class="w3-card w3-margin">
    <div class="w3-container w3-padding">
      <h4>Popular Posts</h4>
    </div>
    <ul href="poem.html" class="w3-ul w3-hoverable w3-white">
      <li class="w3-padding-16">
         <img src="icon.jpg" alt="Image" class="w3-left w3-margin-right" style="width:50px">
        <span class="w3-large">Poems</span><br>
        <span>top 1</span>
      </li>
      <li class="w3-padding-16">
        <img src="icon.jpg" alt="Image" class="w3-left w3-margin-right" style="width:50px">
        <span class="w3-large">Short stories</span><br>
        <span>top 2</span>
      </li> 
      <li class="w3-padding-16">
        <img src="icon.jpg" alt="Image" class="w3-left w3-margin-right" style="width:50px">
        <span class="w3-large">Blog</span><br>
        <span>top 3</span>
      </li>   
    </ul>
  </div>
  <hr> 
 
  <!-- Labels / tags -->
  <div class="w3-card w3-margin">
    <div class="w3-container w3-padding">
     <p class="w3-serif"> Enjoy knowledge while you can
</p>
    
    
    </div>
  </div>
  
<!-- END Introduction Menu -->
</div>

<!-- END GRID -->
</div><br>

<!-- END w3-content -->
</div>

<!-- Footer -->
<div class='w3-container w3-white'>
    <!-- Gunakan ayat yang lebih sesuai pada bahagian ini -->
    <p> Copyright © 2020-2022 : Thoughtsbox.com </p>
    <p>The aim of education is the knowledge, not of facts, but of values.</p>
</div>


</body>
</html>
