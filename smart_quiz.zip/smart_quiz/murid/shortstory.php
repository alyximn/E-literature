<?php
    # memulakan fungsi session_start bagi membolehkan pembolehubah super global
    session_start();

    include ('../header.php');
    include('guard_murid.php');
    include ('../connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Blog</title>
</head>
<body background='images/ngeh.jpg'>

<h1>Simple Blog</h1>

<?php
// Array containing blog post data
$posts = [
    [
        'title' => 'First Post',
        'content' => 'This is the content of the first blog post.',
        'created_at' => '2024-04-01'
    ],
    [
        'title' => 'Second Post',
        'content' => 'This is the content of the second blog post.',
        'created_at' => '2024-04-02'
    ],
    [
        'title' => 'Third Post',
        'content' => 'This is the content of the third blog post.',
        'created_at' => '2024-04-03'
    ]
];

// Loop through each post and display its data
foreach ($posts as $post) {
    echo "<h2>{$post['title']}</h2>";
    echo "<p>{$post['content']}</p>";
    echo "<p>Posted on {$post['created_at']}</p>";
    echo "<hr>";
}
?>

<!-- header -->
<div class="w3-container w3-teal">
  <h1>E-LITERATURE</h1>
</div>

<!-- menu -->
<div class="w3-bar w3-brown">
    <!-- Menu bahagian Murid -->
    <?php
        if (!empty($_SESSION) and basename($_SERVER['PHP_SELF']) != 'index.php') {
            echo "<span class='w3-bar-item'>STUDENT'S NAME: " . $_SESSION['nama_murid'] . "</span>";
            echo "<a class='w3-bar-item w3-button' href='pilih_latihan.php'>HOME PAGE</a>";
            echo "<a class='w3-bar-item w3-button' href='../logout.php'>LOG OUT NOW</a>";
            echo "<a class='w3-bar-item w3-button' href='shortstory'>LOG OUT NOW</a>";
        } else {
            echo "<span class='w3-bar-item'>WELCOME. PLEASE LOG IN</span>";
        }
    ?>
</div>

<?php
    include ('../footer.php');
?>
</body>
</html>
