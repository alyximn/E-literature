<?php
    # memulakan fungsi session_start bagi membolehkan pembolehubah super global
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>E-LITERATURE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body background='images/bro.jpg'>

<!-- header -->
<div class="w3-container w3-brown" style="text-align: center; font-family: 'Times New Roman', Times, serif;">
  <div class="w3-monospace" style="font-size: 50px;">E-LITERATURE</div>
</div>

<!-- menu -->
<div class="w3-bar w3-beige">
    <!-- Menu bahagian Murid -->
    <?php
        if (!empty($_SESSION) and basename($_SERVER['PHP_SELF']) != 'index.php') {
            echo "<span class='w3-bar-item'>STUDENT'S NAME: " . $_SESSION['nama_murid'] . "</span>";
            echo "<a class='w3-bar-item w3-button' href='pilih_latihan.php'>HOME PAGE</a>";
            echo "<a class='w3-bar-item w3-button' href='../signup.php'>SHORT STORY</a>";
              echo "<a class='w3-bar-item w3-button' href='../logout.php'>LOG OUT NOW</a>";
        } else {
            echo "<span class='w3-bar-item'>WELCOME. PLEASE LOG IN</span>";
        }
    ?>
</div>

</body>
</html>

